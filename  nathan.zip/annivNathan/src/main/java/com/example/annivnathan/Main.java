package com.example.annivnathan;

public class Main {
    public static void main(String[] args){
        HelloApplication.main(args);
    }
}
