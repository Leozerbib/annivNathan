package com.example.annivnathan;

import java.util.ArrayList;
import java.util.List;

public class Enigme {
    public static int validate= 0;
    public static List<String> enigmeList= new ArrayList<>();
    public static void set(){
        enigmeList.add("BMSINP");
        enigmeList.add("312211");
        enigmeList.add("QDFGZ");
        enigmeList.add("Montreuil");
        enigmeList.add("Parc");
        enigmeList.add("8718");
        enigmeList.add("!3IJl");
        enigmeList.add("11466");
        enigmeList.add("BNF");
        enigmeList.add("nekE32?");
        enigmeList.add("nde2Smr");
        enigmeList.add("assiette cochonne");
        enigmeList.add("Sour diesel");
        enigmeList.add("2456434443");
        System.out.println(enigmeList.get(0));
        System.out.println(enigmeList.get(1));
    }
}
